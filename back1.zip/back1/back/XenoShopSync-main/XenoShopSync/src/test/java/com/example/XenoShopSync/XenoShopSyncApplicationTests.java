package com.example.XenoShopSync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XenoShopSyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
