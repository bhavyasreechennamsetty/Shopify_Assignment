package com.example.XenoShopSync.dto;

public record UserLoginDto(
        String email,
        String password
) {
}
