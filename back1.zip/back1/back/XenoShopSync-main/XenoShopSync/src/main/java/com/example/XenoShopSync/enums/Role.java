package com.example.XenoShopSync.enums;

public enum Role {
    ADMIN,
    TENANT
}
