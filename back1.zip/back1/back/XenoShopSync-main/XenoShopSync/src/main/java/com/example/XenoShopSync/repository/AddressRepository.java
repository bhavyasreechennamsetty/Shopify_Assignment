package com.example.XenoShopSync.repository;


import com.example.XenoShopSync.entity.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {
}

