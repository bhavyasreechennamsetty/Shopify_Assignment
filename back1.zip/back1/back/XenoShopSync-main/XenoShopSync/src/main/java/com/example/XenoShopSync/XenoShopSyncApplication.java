package com.example.XenoShopSync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XenoShopSyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(XenoShopSyncApplication.class, args);
	}

}
